# Security Issue Reporting & Disclosure Process

If you feel you have found a security issue or concern with Helmet please email the maintainers.

Email Evan Hahn at <me@evanhahn.com> or Adam Baldwin at <baldwin@andyet.net>.

## Expectations
We will do everything we can to communicate in a timely manner and address your concerns, but realize that we do have day jobs and this is in open source project so have a little patience if you don't hear back from us immediatly.

