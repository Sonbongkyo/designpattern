module.exports = require('./lib/bagpipe');
